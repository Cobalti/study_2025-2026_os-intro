---
title: "Отчёт по лабораторной работе №3"
subtitle: "Markdown"
author: "Галиев Самир Салаватович"
date: "2026"
institution: "Российский университет дружбы народов им. Патриса Лулумбы"
faculty: "ФФМиЕН"
department: "Компьютерные и информационные науки"
subject: "Операционные системы"
group: "НКАбд-02-25"
toc: true
toc-depth: 3
numbersections: true
geometry: margin=2cm
fontsize: 14pt
linestretch: 1.5
pdf-engine: xelatex
---

# Введение 
Цель работы: блаблаблабла

Задания:
1. Задани 1
2. Задание 2

# Основная часть

 ыщавхзщылащзыовлаоыва

## Ход работы 

Описание выполненных действий....

![невидимый скриншот](image/none)